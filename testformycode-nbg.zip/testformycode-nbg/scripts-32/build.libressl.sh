#!/bin/sh -e

LIBRESSL_VERSION="3.5.2"

# 创建必要的目录
mkdir -p deps
mkdir -p deps/include
mkdir -p deps/lib

mkdir -p build && cd build

# 下载 LibreSSL 源码
wget https://ftp.openbsd.org/pub/OpenBSD/LibreSSL/libressl-${LIBRESSL_VERSION}.tar.gz -O libressl-${LIBRESSL_VERSION}.tar.gz
tar -xzf libressl-${LIBRESSL_VERSION}.tar.gz

cd libressl-${LIBRESSL_VERSION}

# 强制 32 位编译
export CFLAGS="-m32"
export CXXFLAGS="-m32"

# 配置并编译
./configure --disable-shared
make -j$(nproc || sysctl -n hw.ncpu || sysctl -n hw.logicalcpu)

# 复制头文件和静态库到 deps 目录
cp -fr include ../../deps
cp crypto/.libs/libcrypto.a ../../deps/lib
cp ssl/.libs/libssl.a ../../deps/lib

cd ..
