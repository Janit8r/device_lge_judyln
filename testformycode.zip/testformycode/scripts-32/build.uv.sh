#!/bin/sh -e

UV_VERSION="1.48.0"

# 创建依赖目录
mkdir -p deps
mkdir -p deps/include
mkdir -p deps/lib

mkdir -p build && cd build

# 下载 libuv 源代码
wget https://dist.libuv.org/dist/v${UV_VERSION}/libuv-v${UV_VERSION}.tar.gz -O v${UV_VERSION}.tar.gz
tar -xzf v${UV_VERSION}.tar.gz

cd libuv-v${UV_VERSION}

# 强制 32 位编译
export CFLAGS="-m32"
export CXXFLAGS="-m32"

# 生成配置文件
sh autogen.sh
./configure --disable-shared

# 清理旧的构建文件（可选）
make clean || true

# 编译
make -j$(nproc || sysctl -n hw.ncpu || sysctl -n hw.logicalcpu)

# 复制头文件和静态库到 deps 目录
cp -fr include ../../deps
cp .libs/libuv.a ../../deps/lib
cd ..
