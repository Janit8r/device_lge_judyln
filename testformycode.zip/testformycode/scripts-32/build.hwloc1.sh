#!/bin/sh -e

HWLOC_VERSION="1.11.13"

# 创建需要的目录
mkdir -p deps
mkdir -p deps/include
mkdir -p deps/lib

mkdir -p build && cd build

# 下载 hwloc 源码
wget https://download.open-mpi.org/release/hwloc/v1.11/hwloc-${HWLOC_VERSION}.tar.gz -O hwloc-${HWLOC_VERSION}.tar.gz
tar -xzf hwloc-${HWLOC_VERSION}.tar.gz

cd hwloc-${HWLOC_VERSION}

# 强制 32 位编译
export CFLAGS="-m32"
export CXXFLAGS="-m32"

# 配置编译选项
./configure --disable-shared --enable-static --disable-io --disable-libudev --disable-libxml2

# 编译
make -j$(nproc || sysctl -n hw.ncpu || sysctl -n hw.logicalcpu)

# 复制头文件和静态库到 deps 目录
cp -fr include ../../deps
cp src/.libs/libhwloc.a ../../deps/lib

cd ..
