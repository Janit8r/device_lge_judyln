#!/bin/sh -e

OPENSSL_VERSION="3.0.14"

# 创建依赖目录
mkdir -p deps
mkdir -p deps/include
mkdir -p deps/lib

mkdir -p build && cd build

# 下载 OpenSSL 源代码
wget https://github.com/openssl/openssl/releases/download/openssl-${OPENSSL_VERSION}/openssl-${OPENSSL_VERSION}.tar.gz -O openssl-${OPENSSL_VERSION}.tar.gz
tar -xzf openssl-${OPENSSL_VERSION}.tar.gz

cd openssl-${OPENSSL_VERSION}

# 强制 32 位编译
export CFLAGS="-m32"
export CXXFLAGS="-m32"

# 配置 OpenSSL 构建，禁用共享库和不必要的组件
./Configure linux-generic32 no-shared no-asm no-zlib no-comp no-dgram no-filenames no-cms

# 清理旧的构建文件（可选）
make clean || true

# 编译
make -j$(nproc || sysctl -n hw.ncpu || sysctl -n hw.logicalcpu)

# 复制头文件和静态库到 deps 目录
cp -fr include ../../deps
cp libcrypto.a ../../deps/lib
cp libssl.a ../../deps/lib

cd ..
